import "./App.css";

// White Logo
import whiteLogo from "./resourses/Logo/whiteLogo.png";
// learning img
import learning from "./resourses/illustration/learn.svg";
// summarization
import summarization from "./resourses/img/200.jpg";
// Transaltion
import translation from "./resourses/img/100.jpg";
// web scraping
import scraping from "./resourses/img/300.jpg";

// icons
import { RiHome3Line } from "react-icons/ri";
import { GrGroup } from "react-icons/gr";
import { RiContactsBook2Line } from "react-icons/ri";
import { MdChecklistRtl } from "react-icons/md";
import { MdOutlinePerson } from "react-icons/md";
import { IoMdArrowDown } from "react-icons/io";

import { CgFileDocument } from "react-icons/cg";
import { PiTranslateBold } from "react-icons/pi";
import { HiOutlineGlobe } from "react-icons/hi";

import { IoIosCloseCircleOutline } from "react-icons/io";
import { IoIosCheckmarkCircleOutline } from "react-icons/io";

import { FaFacebook } from "react-icons/fa";

import { SiInstagram } from "react-icons/si";

import { BsTwitterX } from "react-icons/bs";

import { FaGoogle } from "react-icons/fa";

// ==================================== Main APP ==============================
export default function App() {
  return (
    <div>
      <NavBar />
      <HomePage />
      <Footer />
    </div>
  );
}

function HomePage() {
  return (
    <div>
      <Header />
      <Feature />
      <Quote />
      <Plan />
    </div>
  );
}

function NavBar() {
  return (
    <div className="nav-bar">
      <div className="logo-container">
        <img src={whiteLogo} alt="" className="logo" />
      </div>
      <Links />
    </div>
  );
}

function Links() {
  return (
    <>
      <ul className="links">
        <li className="item">
          <RiHome3Line className="icon" />
          <p>Home</p>
        </li>
        <li className="item">
          <MdChecklistRtl className="icon" />
          <p>Plan</p>
        </li>
        <li className="item">
          <GrGroup />
          <p>About Us</p>
        </li>
        <li className="item">
          <RiContactsBook2Line className="icon" />
          <p>Contact Us</p>
        </li>
        <ActionBtn>
          <MdOutlinePerson className="icon" /> Sign Up
        </ActionBtn>
      </ul>
    </>
  );
}

function ActionBtn({ children, fullwidth = "" }) {
  return <button className={`action-btn ${fullwidth}`}>{children}</button>;
}

function Header() {
  return (
    <div className="section-hero">
      <div className="hero">
        <div className="heading-primary">
          <h1>Boost Your Learning Uncover Powerfull Strategies for Success</h1>
          <p className="hero-description">
            Lorem ipsum dolor sit, amet consectetur adipisicing elit. Facilis,
            neque sint? Tempore praesentium labore voluptas nihil voluptatum
            excepturi minima. Quod quae porro nesciunt nam, laboriosam expedita
            maxime similique ab laborum. Tempore nulla ullam eos natus
            consectetur pariatur qui sequi non soluta, expedita vel possimus
            est, maiores fuga, facere harum. Lorem ipsum dolor sit, amet
          </p>
          <ActionBtn>
            Try For Free <IoMdArrowDown className="icon" />
          </ActionBtn>
        </div>
        <div className="hero-img-box">
          <h1 className="hero-img">
            <img src={learning} alt="" />
          </h1>
        </div>
      </div>
    </div>
  );
}

function Feature() {
  return (
    <div className="container">
      <div className="feature-box">
        <SectionHeading subHeading={"Our"} primaryHeading={"Feature"} />
        <div className="feature-card-box">
          <div className="feature-card">
            <img src={summarization} alt="" className="feature-img" />
            <div className="feature-text-box">
              <h3 className="feature-heading">
                <CgFileDocument className="icon" /> Summarization
              </h3>
              <p className="feature-para">
                Lorem ipsum dolor sit amet consectetur adipisicing elit.
                Corrupti hic voluptas ullam aperiam quis impedit maxime maiores
                quas quos? Totam esse saepe possimus accusantium officia unde
                tenetur vitae. Nesciunt, commodi?
              </p>
            </div>
          </div>
          <div className="feature-card">
            {" "}
            <img src={translation} alt="" className="feature-img" />
            <div className="feature-text-box">
              <h3 className="feature-heading">
                <PiTranslateBold className="icon" /> Translate
              </h3>
              <p className="feature-para">
                Lorem ipsum dolor sit amet consectetur adipisicing elit.
                Corrupti hic voluptas ullam aperiam quis impedit maxime maiores
                quas quos? Totam esse saepe possimus accusantium officia unde
                tenetur vitae. Nesciunt, commodi?
              </p>
            </div>
          </div>
          <div className="feature-card">
            <img src={scraping} alt="" className="feature-img" />
            <div className="feature-text-box">
              <h3 className="feature-heading">
                <HiOutlineGlobe className="icon" />
                Scraping
              </h3>
              <p className="feature-para">
                Lorem ipsum dolor sit amet consectetur adipisicing elit.
                Corrupti hic voluptas ullam aperiam quis impedit maxime maiores
                quas quos? Totam esse saepe possimus accusantium officia unde
                tenetur vitae. Nesciunt, commodi?
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function SectionHeading({ subHeading, primaryHeading }) {
  return (
    <div className="section-heading">
      <p className="sub-heading">{subHeading}</p>
      <h3 className="section-primary">{primaryHeading}</h3>
    </div>
  );
}

function Quote() {
  return (
    <div className="container">
      <div className="quote-box">
        <p className="Quote">
          The beautiful thing about learning is that nobody can take it away
          from you.
        </p>
        <div className="person-box">
          <h4 className="person">B.B. King</h4>
        </div>
      </div>
    </div>
  );
}

function Plan() {
  return (
    <div className="container">
      <div className="plan-box">
        <SectionHeading subHeading={"Our"} primaryHeading={"Plan"} />
        <div className="plan-card-box">
          <div className="plan-card">
            <h3 className="plan-heading">Free</h3>
            <h1 className="plan-ammount">0</h1>
            <div className="plan-feature">
              <IoIosCheckmarkCircleOutline className="icon" />
              <p className="plane-feature-text">Unlimited Access</p>
              <IoIosCloseCircleOutline className="icon" />
              <p className="plane-feature-text">History</p>
              <IoIosCloseCircleOutline className="icon" />
              <p className="plane-feature-text">Regional Language</p>
            </div>
            <ActionBtn fullwidth="full-width subscribe-btn">
              Subscribe
            </ActionBtn>
          </div>
          <div className="plan-card best-plan">
            <h3 className="plan-heading">premium </h3>
            <h1 className="plan-ammount">10</h1>
            <div className="plan-feature">
              <IoIosCheckmarkCircleOutline className="icon" />
              <p className="plane-feature-text">Unlimited Access</p>
              <IoIosCheckmarkCircleOutline className="icon" />
              <p className="plane-feature-text">History</p>
              <IoIosCheckmarkCircleOutline className="icon" />
              <p className="plane-feature-text">Regional Language</p>
            </div>
            <ActionBtn fullwidth="full-width">Subscribe</ActionBtn>
          </div>
        </div>
      </div>
    </div>
  );
}

function Footer() {
  return (
    <>
      <div className="footer">
        {/* <img src={whiteLogo} alt="" className="footer-logo" /> */}
        <div className="social-media-links">
          <FaFacebook className="sm-icon" />
          <SiInstagram className="sm-icon" />
          <BsTwitterX className="sm-icon" />
          <FaGoogle className="sm-icon" />
        </div>
        <p className="copy-right">
          Copyright © 2024 Design By Yaseen Amin & Basit Ali
        </p>
      </div>
    </>
  );
}
